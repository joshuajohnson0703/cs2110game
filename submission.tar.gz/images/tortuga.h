/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 tortuga tortuga.png 
 * Time-stamp: Tuesday 04/04/2023, 02:19:18
 * 
 * Image Information
 * -----------------
 * tortuga.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TORTUGA_H
#define TORTUGA_H

extern const unsigned short tortuga[400];
#define TORTUGA_SIZE 800
#define TORTUGA_LENGTH 400
#define TORTUGA_WIDTH 20
#define TORTUGA_HEIGHT 20

#endif

