/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 jessuh jessuh.png 
 * Time-stamp: Tuesday 04/04/2023, 21:18:05
 * 
 * Image Information
 * -----------------
 * jessuh.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JESSUH_H
#define JESSUH_H

extern const unsigned short jessuh[400];
#define JESSUH_SIZE 800
#define JESSUH_LENGTH 400
#define JESSUH_WIDTH 20
#define JESSUH_HEIGHT 20

#endif

