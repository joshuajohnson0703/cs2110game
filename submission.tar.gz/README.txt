Welcome to Breaking Bad CS 2110 Edition created by a somewhat of a Breaking Bad fan...

The game is fairly simple, you have to get the "Blue stuff" before time runs out (before the cops catch you :3 )
If time runs out, game over.

When you enter the game,
you press enter to move to the character select state.

When you enter the character select state,
move the left or right keys to select which character you want. Walter White or Jesse Pinkman (Characters of the show)

Now you are in game,
Left or right keys are to move left and right and additional jump is added in case you want to move faster.

If you are slow, 
GAME OVER

If you are speed,
Good job


The select button will work at any point and will return back to the start state and reset the entire program.


Hope you have fun!