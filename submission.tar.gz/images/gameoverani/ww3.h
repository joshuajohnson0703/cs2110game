/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww3 ww3.png 
 * Time-stamp: Tuesday 04/04/2023, 13:40:51
 * 
 * Image Information
 * -----------------
 * ww3.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW3_H
#define WW3_H

extern const unsigned short ww3[38400];
#define WW3_SIZE 76800
#define WW3_LENGTH 38400
#define WW3_WIDTH 240
#define WW3_HEIGHT 160

#endif

