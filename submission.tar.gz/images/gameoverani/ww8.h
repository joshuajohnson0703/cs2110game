/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww8 ww8.png 
 * Time-stamp: Tuesday 04/04/2023, 13:41:23
 * 
 * Image Information
 * -----------------
 * ww8.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW8_H
#define WW8_H

extern const unsigned short ww8[38400];
#define WW8_SIZE 76800
#define WW8_LENGTH 38400
#define WW8_WIDTH 240
#define WW8_HEIGHT 160

#endif

