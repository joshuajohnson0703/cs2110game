/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 jesse jesse.png 
 * Time-stamp: Tuesday 04/04/2023, 14:36:24
 * 
 * Image Information
 * -----------------
 * jesse.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JESSE_H
#define JESSE_H

extern const unsigned short jesse[38400];
#define JESSE_SIZE 76800
#define JESSE_LENGTH 38400
#define JESSE_WIDTH 240
#define JESSE_HEIGHT 160

#endif

