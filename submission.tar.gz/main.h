#ifndef MAIN_H
#define MAIN_H

#include "gba.h"

// TODO: Create any necessary structs
#define s 2
/*
* For example, for a Snake game, one could be:
*
* struct snake {
*   int heading;
*   int length;
*   int row;
*   int col;
* };
*
* Example of a struct to hold state machine data:
*
* struct state {
*   int currentState;
*   int nextState;
* };
*
*/


struct walt {
    int walterX;
    int walterY;
};

struct jussuh {
    int jesseX;
    int jesseY;
};

struct tort {
    int tx;
    int ty;
};

#endif
