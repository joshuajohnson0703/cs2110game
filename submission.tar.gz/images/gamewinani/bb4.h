/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bb4 bb4.png 
 * Time-stamp: Tuesday 04/04/2023, 20:36:25
 * 
 * Image Information
 * -----------------
 * bb4.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB4_H
#define BB4_H

extern const unsigned short bb4[38400];
#define BB4_SIZE 76800
#define BB4_LENGTH 38400
#define BB4_WIDTH 240
#define BB4_HEIGHT 160

#endif

