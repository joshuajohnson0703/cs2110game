/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww13 ww13.png 
 * Time-stamp: Tuesday 04/04/2023, 13:42:24
 * 
 * Image Information
 * -----------------
 * ww13.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW13_H
#define WW13_H

extern const unsigned short ww13[38400];
#define WW13_SIZE 76800
#define WW13_LENGTH 38400
#define WW13_WIDTH 240
#define WW13_HEIGHT 160

#endif

