/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 bb bb.png 
 * Time-stamp: Tuesday 04/04/2023, 01:32:18
 * 
 * Image Information
 * -----------------
 * bb.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB_H
#define BB_H

extern const unsigned short bb[625];
#define BB_SIZE 1250
#define BB_LENGTH 625
#define BB_WIDTH 25
#define BB_HEIGHT 25

#endif

