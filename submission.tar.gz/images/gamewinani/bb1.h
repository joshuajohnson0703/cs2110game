/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bb1 bb1.png 
 * Time-stamp: Tuesday 04/04/2023, 20:36:11
 * 
 * Image Information
 * -----------------
 * bb1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB1_H
#define BB1_H

extern const unsigned short bb1[38400];
#define BB1_SIZE 76800
#define BB1_LENGTH 38400
#define BB1_WIDTH 240
#define BB1_HEIGHT 160

#endif

