/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bb2 bb2.png 
 * Time-stamp: Tuesday 04/04/2023, 20:36:17
 * 
 * Image Information
 * -----------------
 * bb2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB2_H
#define BB2_H

extern const unsigned short bb2[38400];
#define BB2_SIZE 76800
#define BB2_LENGTH 38400
#define BB2_WIDTH 240
#define BB2_HEIGHT 160

#endif

