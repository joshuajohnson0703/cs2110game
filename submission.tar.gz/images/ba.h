/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 ba ba.png 
 * Time-stamp: Tuesday 04/04/2023, 01:32:23
 * 
 * Image Information
 * -----------------
 * ba.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BA_H
#define BA_H

extern const unsigned short ba[625];
#define BA_SIZE 1250
#define BA_LENGTH 625
#define BA_WIDTH 25
#define BA_HEIGHT 25

#endif

