/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bb6 bb6.png 
 * Time-stamp: Tuesday 04/04/2023, 20:36:33
 * 
 * Image Information
 * -----------------
 * bb6.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB6_H
#define BB6_H

extern const unsigned short bb6[38400];
#define BB6_SIZE 76800
#define BB6_LENGTH 38400
#define BB6_WIDTH 240
#define BB6_HEIGHT 160

#endif

