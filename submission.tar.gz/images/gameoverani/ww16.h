/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww16 ww16.png 
 * Time-stamp: Tuesday 04/04/2023, 13:42:39
 * 
 * Image Information
 * -----------------
 * ww16.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW16_H
#define WW16_H

extern const unsigned short ww16[38400];
#define WW16_SIZE 76800
#define WW16_LENGTH 38400
#define WW16_WIDTH 240
#define WW16_HEIGHT 160

#endif

