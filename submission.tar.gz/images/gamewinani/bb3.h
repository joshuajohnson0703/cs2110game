/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bb3 bb3.png 
 * Time-stamp: Tuesday 04/04/2023, 20:36:21
 * 
 * Image Information
 * -----------------
 * bb3.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BB3_H
#define BB3_H

extern const unsigned short bb3[38400];
#define BB3_SIZE 76800
#define BB3_LENGTH 38400
#define BB3_WIDTH 240
#define BB3_HEIGHT 160

#endif

