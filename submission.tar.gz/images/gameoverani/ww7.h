/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww7 ww7.png 
 * Time-stamp: Tuesday 04/04/2023, 13:41:17
 * 
 * Image Information
 * -----------------
 * ww7.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW7_H
#define WW7_H

extern const unsigned short ww7[38400];
#define WW7_SIZE 76800
#define WW7_LENGTH 38400
#define WW7_WIDTH 240
#define WW7_HEIGHT 160

#endif

