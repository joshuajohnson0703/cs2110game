/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww1 ww1.png 
 * Time-stamp: Tuesday 04/04/2023, 13:40:33
 * 
 * Image Information
 * -----------------
 * ww1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW1_H
#define WW1_H

extern const unsigned short ww1[38400];
#define WW1_SIZE 76800
#define WW1_LENGTH 38400
#define WW1_WIDTH 240
#define WW1_HEIGHT 160

#endif

