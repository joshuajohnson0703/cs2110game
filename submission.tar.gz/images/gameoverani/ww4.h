/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww4 ww4.png 
 * Time-stamp: Tuesday 04/04/2023, 13:40:57
 * 
 * Image Information
 * -----------------
 * ww4.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW4_H
#define WW4_H

extern const unsigned short ww4[38400];
#define WW4_SIZE 76800
#define WW4_LENGTH 38400
#define WW4_WIDTH 240
#define WW4_HEIGHT 160

#endif

