/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 start2 start2.png 
 * Time-stamp: Tuesday 04/04/2023, 21:04:12
 * 
 * Image Information
 * -----------------
 * start2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef START2_H
#define START2_H

extern const unsigned short start2[38400];
#define START2_SIZE 76800
#define START2_LENGTH 38400
#define START2_WIDTH 240
#define START2_HEIGHT 160

#endif

