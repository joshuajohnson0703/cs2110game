/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 tortuga2 tortuga2.png 
 * Time-stamp: Tuesday 04/04/2023, 02:19:29
 * 
 * Image Information
 * -----------------
 * tortuga2.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TORTUGA2_H
#define TORTUGA2_H

extern const unsigned short tortuga2[400];
#define TORTUGA2_SIZE 800
#define TORTUGA2_LENGTH 400
#define TORTUGA2_WIDTH 20
#define TORTUGA2_HEIGHT 20

#endif

