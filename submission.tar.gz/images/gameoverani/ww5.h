/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww5 ww5.png 
 * Time-stamp: Tuesday 04/04/2023, 13:41:04
 * 
 * Image Information
 * -----------------
 * ww5.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW5_H
#define WW5_H

extern const unsigned short ww5[38400];
#define WW5_SIZE 76800
#define WW5_LENGTH 38400
#define WW5_WIDTH 240
#define WW5_HEIGHT 160

#endif

