/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 walter walter.png 
 * Time-stamp: Tuesday 04/04/2023, 20:59:08
 * 
 * Image Information
 * -----------------
 * walter.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WALTER_H
#define WALTER_H

extern const unsigned short walter[400];
#define WALTER_SIZE 800
#define WALTER_LENGTH 400
#define WALTER_WIDTH 20
#define WALTER_HEIGHT 20

#endif

