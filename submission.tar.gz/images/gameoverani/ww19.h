/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww19 ww19.png 
 * Time-stamp: Tuesday 04/04/2023, 13:43:26
 * 
 * Image Information
 * -----------------
 * ww19.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW19_H
#define WW19_H

extern const unsigned short ww19[38400];
#define WW19_SIZE 76800
#define WW19_LENGTH 38400
#define WW19_WIDTH 240
#define WW19_HEIGHT 160

#endif

