/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww15 ww15.png 
 * Time-stamp: Tuesday 04/04/2023, 13:42:34
 * 
 * Image Information
 * -----------------
 * ww15.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW15_H
#define WW15_H

extern const unsigned short ww15[38400];
#define WW15_SIZE 76800
#define WW15_LENGTH 38400
#define WW15_WIDTH 240
#define WW15_HEIGHT 160

#endif

