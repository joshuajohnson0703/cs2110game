/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww6 ww6.png 
 * Time-stamp: Tuesday 04/04/2023, 13:41:11
 * 
 * Image Information
 * -----------------
 * ww6.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW6_H
#define WW6_H

extern const unsigned short ww6[38400];
#define WW6_SIZE 76800
#define WW6_LENGTH 38400
#define WW6_WIDTH 240
#define WW6_HEIGHT 160

#endif

