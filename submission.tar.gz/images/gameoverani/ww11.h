/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ww11 ww11.png 
 * Time-stamp: Tuesday 04/04/2023, 13:41:40
 * 
 * Image Information
 * -----------------
 * ww11.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WW11_H
#define WW11_H

extern const unsigned short ww11[38400];
#define WW11_SIZE 76800
#define WW11_LENGTH 38400
#define WW11_WIDTH 240
#define WW11_HEIGHT 160

#endif

